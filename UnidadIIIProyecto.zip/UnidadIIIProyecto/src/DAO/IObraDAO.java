/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Obra;
import java.util.List;

/**
 *
 * @author Andrea Plascencia
 */
public interface IObraDAO extends IDAO <Obra, Integer> {
    
    List<Obra> obtenerObrasPorAutor (int idAutor) throws DAOException;
    
}
