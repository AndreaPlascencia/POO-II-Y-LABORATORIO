/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author Andrea Plascencia
 */
public class Exposicion {
    
    //Campos o propiedades
    private int idExposicion;
    private int idGaleria;
    private String tituloExposicion;
    private Date fechaInicio;
    private Date fechaFinal;
    
    //Constructor sin parámetros
    public Exposicion () {
        
    }
    
    //Constructor con cuatro parámetros
    public Exposicion (int idGaleria, String tituloExposicion, 
            Date fechaInicio, Date fechaFinal) {
        this.setIdGaleria(idGaleria);
        this.setTituloExposicion(tituloExposicion);
        this.setFechaInicio(fechaInicio);
        this.setFechaFinal(fechaFinal);
    }
    
    //Constructor con cinco parámetros
    public Exposicion (int idExposicion, int idGaleria, String tituloExposicion, 
            Date fechaInicio, Date fechaFinal) {
        this.setIdExposicion(idExposicion);
        this.setIdGaleria(idGaleria);
        this.setTituloExposicion(tituloExposicion);
        this.setFechaInicio(fechaInicio);
        this.setFechaFinal(fechaFinal);
    }
    
    //Descriptores de acesso

    /**
     * @return the idExposicion
     */
    public int getIdExposicion() {
        return idExposicion;
    }

    /**
     * @param idExposicion the idExposicion to set
     */
    public void setIdExposicion(int idExposicion) {
        this.idExposicion = idExposicion;
    }

    /**
     * @return the idGaleria
     */
    public int getIdGaleria() {
        return idGaleria;
    }

    /**
     * @param idGaleria the idGaleria to set
     */
    public void setIdGaleria(int idGaleria) {
        this.idGaleria = idGaleria;
    }

    /**
     * @return the tituloExposicion
     */
    public String getTituloExposicion() {
        return tituloExposicion;
    }

    /**
     * @param tituloExposicion the tituloExposicion to set
     */
    public void setTituloExposicion(String tituloExposicion) {
        this.tituloExposicion = tituloExposicion;
    }

    /**
     * @return the fechaInicio
     */
    public Date getFechaInicio() {
        return fechaInicio;
    }

    /**
     * @param fechaInicio the fechaInicio to set
     */
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * @return the fechaFinal
     */
    public Date getFechaFinal() {
        return fechaFinal;
    }

    /**
     * @param fechaFinal the fechaFinal to set
     */
    public void setFechaFinal(Date fechaFinal) {
        this.fechaFinal = fechaFinal;
    }
    
}//Fin de la clase Exposicion
