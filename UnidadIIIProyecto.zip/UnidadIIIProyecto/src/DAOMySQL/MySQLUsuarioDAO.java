/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySQL;

import DAO.DAOException;
import DAO.IUsuarioDAO;
import Modelo.Usuario;
import MySQLConexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Andrea Plascencia
 */
public class MySQLUsuarioDAO implements IUsuarioDAO {
    
    //Propiedades para manipular la base de datos
    private Connection conn = null;
    private ResultSet rs = null;
    private PreparedStatement ps = null;
    
    //Consulta SQL que utilizaremos
    private final String GETONE = "SELECT idUsuario, usuario, clave"
            + " FROM usuario WHERE idUsuario = ?";

    @Override
    public void insertar(Usuario a) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void modificar(Usuario a) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminar(Integer id) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    /**
     * Método que obtendrá al usuario que controlará la base de datos
     * @param id
     * @return
     * @throws DAOException 
     */
    @Override
    public Usuario obtener(Integer id) throws DAOException {
        //Autor a retornar
        Usuario miUsuario = null;
        
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta y definimos sus parámetros que recibe la consulta
            ps = conn.prepareStatement(GETONE);
            ps.setInt(1, id);
            
            //Ejecutamos la consulta y almacenamos el resultado en un objeto ResultSet
            rs = ps.executeQuery();
            
            /*
            Verificamos si el ResultSet obtuvo un resultado y lo asignamos al objeto
            correspondiente
            */
            if (rs.next()) {
                miUsuario = new Usuario();
                miUsuario.setIdUsuario(rs.getInt("idUsuario"));
                miUsuario.setUsuario(rs.getString("usuario"));
                miUsuario.setClave(rs.getString("clave"));
            }else {
                throw new DAOException ("No existe un usuario");
            }//Fin del if else
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
        
        return miUsuario;
    }//Fin del método obtener
    
    private void cerrarConexiones 
        (PreparedStatement ps, ResultSet rs, Connection conn) throws DAOException {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL", ex);
        }
    }//Fin del método cerrarConexiones
    
}//Fin de la clase MySQLUsuarioDAO
