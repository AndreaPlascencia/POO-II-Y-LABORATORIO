/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySQL;

import DAO.DAOException;
import DAO.IAutorDAO;
import Modelo.Autor;
import MySQLConexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Andrea Plascencia
 */
public class MySQLAutorDAO implements IAutorDAO {
    
    //Propiedades para controlar la base de datos
    private Connection conn = null;
    private ResultSet rs = null;
    private PreparedStatement ps = null;
    
    //Consultas SQL
    private final String INSERT = "INSERT INTO autor (nombreAutor, apellidos)"
            + " VALUES (?, ?)";
    
    private final String UPDATE = "UPDATE autor SET nombreAutor = ?, apellidos = ?"
            + " WHERE idAutor = ?";
    
    private final String DELETE = "DELETE FROM autor WHERE idAutor = ?";
    
    private final String GETONE = "SELECT idAutor, nombreAutor, apellidos"
            + " FROM autor WHERE idAutor = ?";
    
    /**
     * Método para insertar un autor
     * @param autor Que se insertará
     * @throws DAOException 
     */
    @Override
    public void insertar(Autor autor) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando los parámetros
            ps = conn.prepareStatement(INSERT,
                    PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, autor.getNombreAutor());
            ps.setString(2, autor.getApellidos());
            
            //Ejecutamos la cosulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("No se pudo guardar el nuevo autor");
            }else {
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    autor.setIdAutor(rs.getInt(1));
                }else {
                    throw new DAOException("No se pudo "
                            + "asignar el ID a este autor");
                }
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método insertar
    
    /**
     * Método para modificar un autor
     * @param autor
     * @throws DAOException 
     */
    @Override
    public void modificar(Autor autor) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando los parámetros de entrada
            ps = conn.prepareStatement(UPDATE);
            ps.setString(1, autor.getNombreAutor());
            ps.setString(2, autor.getApellidos());
            ps.setInt(3, autor.getIdAutor());
            
            //Ejecutamos la consulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema "
                        + "y no se guardaron los cambios");
            }
        }catch (SQLException ex) {
            throw new DAOException("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método modificar
    
    /**
     * Método para eliminar un autor
     * @param idAutor que se eliminará
     * @throws DAOException 
     */
    @Override
    public void eliminar(Integer idAutor) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando parametros de entrada
            ps = conn.prepareStatement(DELETE);
            ps.setInt(1, idAutor);
            
            //Ejecutamos la consulta y verificamos el resultado 
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema y no se pudo eliminar"
                        + " el registro");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método eliminar
    
    /**
     * Método que obtiene los datos del autor
     * @param idAutor
     * @return
     * @throws DAOException 
     */
    @Override
    public Autor obtener(Integer idAutor) throws DAOException {
        //Autor a retornar
        Autor miAutor = null;
        
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando sus parámetros
            ps = conn.prepareStatement(GETONE);
            ps.setInt(1, idAutor);
            
            //Ejecutamos la consulta y almacenamos en un objeto ResultSet
            rs = ps.executeQuery();
            
            /*
            Verificamos si el ResultSet obtuvo un resultado y lo asignamos al objeto
            correspondiente
            */
            if (rs.next()) {
                miAutor = new Autor();
                miAutor.setIdAutor(rs.getInt("idAutor"));
                miAutor.setNombreAutor(rs.getString("nombreAutor"));
                miAutor.setApellidos(rs.getString("apellidos"));
            }else {
                throw new DAOException ("No se encontro el autor");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
        
        return miAutor;
    }//Fin del método obtener
    
    private void cerrarConexiones 
        (PreparedStatement ps, ResultSet rs, Connection conn) throws DAOException {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL", ex);
        }
    }//Fin del método cerrarConexiones
        
}//Fin de la clase MySQLAutorDAO
