/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MySQLConexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Andrea Plascencia
 */
public class Conectar {
    
    //Propiedades para la conexión a la base de datos
    
    //Nombre del controlador JDBC
    private static final String CONTROLADOR = "com.mysql.jdbc.Driver";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "";
    private static final String URL_BASEDATOS = "jdbc:mysql://localhost/proyecto?useSSL=false";
    
    
    private static Connection conn = null;
    
    
    /**
     * Ralizamos la conexión a la base de datos 
     * @return 
     * @throws SQLException 
     */
    public static Connection realizarConexion() throws SQLException {
        try {
            
            //Carga la clase controlador 
            Class.forName(CONTROLADOR);
            
            //Establece la conexión a la base de datos
            conn = DriverManager.getConnection(URL_BASEDATOS, USUARIO, PASSWORD);
            
        }catch (ClassNotFoundException ex) {
            Logger.getLogger(Conectar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return conn;
    }//Fin del método realizarConexion
    
    /**
     * Realiza la desconexión de la base de datos
     * @throws SQLException 
     */
    public static void realizarDesconexion() throws SQLException {
        if (conn != null) {
            //Cierra la conexión a la base de datos
            conn.close();
        }
    }//Fin del método realizarDesconexión
    
}//Fin de la clase Conectar